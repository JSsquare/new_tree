/**
    Copyright 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

        http://aws.amazon.com/apache2.0/

    or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
*/

/**
 * This simple sample has no external dependencies or session management, and shows the most basic
 * example of how to create a Lambda function for handling Alexa Skill requests.
 *
 * Examples:
 * One-shot model:
 *  User: "Alexa, ask Space Geek for a space fact"
 *  Alexa: "Here's your space fact: ..."
 */

/**
 * App ID for the skill
 */
var req = require('request');

var APP_ID = undefined; //OPTIONAL: replace with "amzn1.echo-sdk-ams.app.[your-unique-value-here]";

/**
 * Array containing space facts.
 */
var FACTS = ["I love ", "I hate "];

/**
 * The AlexaSkill prototype and helper functions
 */
var AlexaSkill = require('./AlexaSkill');

/**
 * SpaceGeek is a child of AlexaSkill.
 * To read more about inheritance in JavaScript, see the link below.
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Introduction_to_Object-Oriented_JavaScript#Inheritance
 */
var Trition = function () {
    AlexaSkill.call(this, APP_ID);
};

// Extend AlexaSkill
Trition.prototype = Object.create(AlexaSkill.prototype);
Trition.prototype.constructor = Trition;

Trition.prototype.eventHandlers.onSessionStarted = function (sessionStartedRequest, session) {
    //console.log("onSessionStarted requestId: " + sessionStartedRequest.requestId + ", sessionId: " + session.sessionId);
    // any initialization logic goes here
};

Trition.prototype.eventHandlers.onLaunch = function (launchRequest, session, response) {
    //console.log("onLaunch requestId: " + launchRequest.requestId + ", sessionId: " + session.sessionId);
    //ndleNewFactRequest(response);
};

/**
 * Overridden to show that a subclass can override this function to teardown session state.
 */
Trition.prototype.eventHandlers.onSessionEnded = function (sessionEndedRequest, session) {
    // any cleanup logic goes here
};

Trition.prototype.intentHandlers = {
    "nutritionIntent": function (intent, session, response) {                
        handleNewFactRequest(response, intent.slots.food);
    },

    "AMAZON.HelpIntent": function (intent, session, response) {
        response.ask("Help yourself. Eat healthy");
    },

    "AMAZON.StopIntent": function (intent, session, response) {
        var speechOutput = "Goodbye, stay healthy";
        response.tell(speechOutput);
    },

    "AMAZON.CancelIntent": function (intent, session, response) {
        var speechOutput = "Goodbye, stay healthy";
        response.tell(speechOutput);
    }
};

/**
 * Gets a random new fact from the list and returns to the user.
 */
function handleNewFactRequest(response, food) {
    var factIndex = Math.floor(Math.random() * FACTS.length);
    var randomFact = FACTS[factIndex];

    var speechOutput = "Here's your fact: " + randomFact + food.value; 
    var cardTitle = "Response";

    req.post({
       url: 'https://trackapi.nutritionix.com/v2/natural/nutrients',
       headers: {
          'Content-Type': 'application/x-www-form-urlencoded', 
          'x-app-id': 'b3d1c4f0',
          'x-app-key' : '9d6e27138ae5ffd22c070edb3cd8975a' 
       },
       'body': "query=pizza",
       method: 'POST'
      },

      function (e, r, body) {
          console.log("-----------------------", body);
      });    
            

    
    
    response.tellWithCard(speechOutput, cardTitle, speechOutput);
}


// Create the handler that responds to the Alexa Request.
exports.handler = function (event, context) {
    var trition = new Trition();
    trition.execute(event, context);
};